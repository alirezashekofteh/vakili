{{-- <div class="xs-sidebar-group info-group">
    <div class="xs-overlay xs-bg-black"></div>
    <div class="xs-sidebar-widget">
        <div class="sidebar-widget-container">
            <div class="widget-heading">
                <a href="#" class="close-side-widget">
                    X
                </a>
            </div>
            <div class="sidebar-textwidget">
                
                <!-- Sidebar Info Content -->
                <div class="sidebar-info-contents">
                    <div class="content-inner">
                        <div class="logo">
                            <a href="index.html"><img src="images/logo-2.png" alt="" /></a>
                        </div>
                        <div class="content-box">
                            <h2> درباره ما </h2>
                            <p class="text">استدلال به نفع استفاده از متن پرکننده چیزی شبیه به این است: اگر در فرآیند مشاوره از محتوای واقعی استفاده می کنید ، هر زمان که به یک نقطه بررسی رسیدید ، در نهایت خود و نه طرح محتوا را بررسی و مذاکره می کنید.</p>
                            <a href="#" class="theme-btn btn-style-three"><span class="txt">مشاوره </span></a>
                        </div>
                        <div class="contact-info">
                            <h2>اطلاعات تماس </h2>
                            <ul class="list-style-one">
                                <li><span class="icon fa fa-location-arrow"></span>شیکاگو، مرکز لوراس منطقه سه</li>
                                <li><span class="icon fa fa-phone"></span>(111) 111-111-1111</li>
                                <li><span class="icon fa fa-envelope"></span>globex@gmail.com</li>
                                <li><span class="icon fa fa-clock-o"></span>شنبه - چهارشنبه | ساعت کاری 9 صبح تا 19 عصر</li>
                            </ul>
                        </div>
                        <!-- Social Box -->
                        <ul class="social-box">
                            <li class="facebook"><a href="#" class="fa fa-facebook-f"></a></li>
                            <li class="twitter"><a href="#" class="fa fa-twitter"></a></li>
                            <li class="linkedin"><a href="#" class="fa fa-linkedin"></a></li>
                            <li class="instagram"><a href="#" class="fa fa-instagram"></a></li>
                            <li class="youtube"><a href="#" class="fa fa-youtube"></a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div> --}}